#include <iostream>
using namespace std;
int main()
{
	FILE *fp;
	fp=fopen("d:\\myfiles\\sample.txt", "a");
	if(!fp)
	{
		cout << "Cannot open file.\n";
		system("pause");
		exit(1);
	}
	fputc('\n', fp);
	//Prints and append character ASCII value from 97-122 (a-z) to a file
	for(int i=97; 1<123;i++)
		fputc(i,fp);
	fclose(fp);
	return 0;
}