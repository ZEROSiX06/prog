#include<iostream>
#include<windows.h>
#include <bits/stdc++.h>
#include<conio.h>
#include<stdio.h>
#include <string.h>
#include<ctime>
#include<cstdlib>
#include<time.h>
#define g gotoxy


using namespace std;

void menu();
void exshits();


int control;
void gotoxy( int column, int line )
{
	HANDLE screen = GetStdHandle( STD_OUTPUT_HANDLE );
	COORD max_size = GetLargestConsoleWindowSize( screen );
	COORD coord;
	coord.X = column;
	coord.Y = line;
	SetConsoleCursorPosition(GetStdHandle( STD_OUTPUT_HANDLE ),coord);
}


int aSquare(){
	system("CLS");
	
	double x;
	bool validX = false;
	while (!validX){ //data validation
		validX = true;
		g(77,10);cout << "PLEASE INPUT THE LENGTH:"; cin >> x;
		if(cin.fail()){
			cin.clear();
			cin.ignore();
		g(77,10);cout << "                                    " ;
		g(77,11);cout << "Please enter numbers only.";
			validX = false;
		}
	}
	double area = x*x;
	g(50,7);cout << "THE AREA IS :" << area <<endl<<endl;
	
	g(50,9);cout << "PLEASE CHOOSE" <<endl;
	g(50,10);cout << "1: AGAIN" <<endl;
	g(50,11);cout << "2: BACK TO MENU"<<endl;
		
	
		int name, mode;
		int preset=0, choosemenu=0;	
		while(1){
			preset:
			if(kbhit()){ // para deretso keys 1,2 -- para d na mag input ng anong kababalaghan
				
				name=getch();
				if (name !=49 && name!=50)
	            goto preset;
	            
				if(name == 49){ //value ng 1 sa ascii
				mode=1;
				goto choosemenu;
					break;
				}
				if(name == 50){ //value ng 2 sa ascii
				mode=2;
				goto choosemenu;
					break;
				}
			choosemenu:
			switch(mode){
				case 1:{
					system ("CLS");
					aSquare();
					break;
				}
				case 2:{
					system ("CLS");
					menu();
					break;
				}
			}
		}
	}
}
int aRectangle(){
	system("CLS");
	

	double x;
	double y;
	bool validX = false;
	bool validY = false;
	while (!validX){ //data validation
		validX = true;
		g(77,10);cout << "PLEASE INPUT THE LENGTH:"; cin >> x;
		if(cin.fail()){
			cin.clear();
			cin.ignore();
		g(77,10);cout << "                                    " ;
		g(77,11);cout << "Please enter numbers only.";
			validX = false;
		}
	}
	while (!validY){ //data validation
		validY = true;
		g(77,12);cout << "PLEASE INPUT THE WIDTH:"; cin >> y;
		if(cin.fail()){
			cin.clear();
			cin.ignore();
		g(77,12);cout << "                                    " ;
		g(77,13);cout << "Please enter numbers only.";
			validY = false;
		}
	}
	
	double area = x*y;
	g(50,10);cout << "THE AREA IS :" << area <<endl<<endl;
	
	g(50,12);cout << "PLEASE CHOOSE" <<endl;
	g(50,13);cout << "1: AGAIN" <<endl;
	g(50,14);cout << "2: BACK TO MENU"<<endl;
		
	
	int name, mode;
		int preset=0, choosemenu=0;	
		while(1){
			preset:
			if(kbhit()){ // para deretso keys 1,2 -- para d na mag input ng anong kababalaghan
				
				name=getch();
				if (name !=49 && name!=50)
	            goto preset;
	            
				if(name == 49){ //value ng 1 sa ascii
				mode=1;
				goto choosemenu;
					break;
				}
				if(name == 50){ //value ng 2 sa ascii
				mode=2;
				goto choosemenu;
					break;
				}
			choosemenu:
			switch(mode){
				case 1:{
					system ("CLS");
					aRectangle();
					break;
				}
				case 2:{
					system ("CLS");
					menu();
					break;
				}
			}
		}
	}
}
int aTriangle(){
	system("CLS");

	double x;
	double y;
	bool validX = false;
	bool validY = false;
	while (!validX){ //data validation
		validX = true;
		g(77,10);cout << "PLEASE INPUT THE BASE:"; cin >> x;
		if(cin.fail()){
			cin.clear();
			cin.ignore();
		g(77,10);cout << "                                    " ;
		g(77,11);cout << "Please enter numbers only.";
			validX = false;
		}
	}
	while (!validY){ //data validation
		validY = true;
		g(77,12);cout << "PLEASE INPUT THE HEIGHT:"; cin >> y;
		if(cin.fail()){
			cin.clear();
			cin.ignore();
		g(77,12);cout << "                                    " ;
		g(77,13);cout << "Please enter numbers only.";
			validY = false;
		}
	}
	
	double area = (x*y)/2;
	g(50,10);cout << "THE AREA IS :" << area <<endl<<endl;
	
	g(50,12);cout << "PLEASE CHOOSE" <<endl;
	g(50,13);cout << "1: AGAIN" <<endl;
	g(50,14);cout << "2: BACK TO MENU"<<endl;
	
	int name, mode;
		int preset=0, choosemenu=0;	
		while(1){
			preset:
			if(kbhit()){ // para deretso keys 1,2 -- para d na mag input ng anong kababalaghan
				
				name=getch();
				if (name !=49 && name!=50)
	            goto preset;
	            
				if(name == 49){ //value ng 1 sa ascii
				mode=1;
				goto choosemenu;
					break;
				}
				if(name == 50){ //value ng 2 sa ascii
				mode=2;
				goto choosemenu;
					break;
				}
			choosemenu:
			switch(mode){
				case 1:{
					system ("CLS");
					aTriangle();
					break;
				}
				case 2:{
					system ("CLS");
					menu();
					break;
				}
			}
		}
	}
}
int aCircle(){
	system("CLS");
	
	double x;
	again:
		g(77,10);cout << "PLEASE INPUT THE RADIUS:"; cin >> x;
		if(cin.fail()){
			cin.clear();
			cin.ignore(1000,'\n');
		g(77,11);cout << "Please enter numbers only.";
		goto again;
		}
	double area = (x*x)*3.1416;
	g(50,7);cout << "THE AREA IS :" << area <<endl<<endl;
	
	g(50,9);cout << "PLEASE CHOOSE" <<endl;
	g(50,10);cout << "1: AGAIN" <<endl;
	g(50,11);cout << "2: BACK TO MENU"<<endl;
		
	int name, mode;
		int preset=0, choosemenu=0;	
		while(1){
			preset:
			if(kbhit()){ // para deretso keys 1,2 -- para d na mag input ng anong kababalaghan
				
				name=getch();
				if (name !=49 && name!=50)
	            goto preset;
	            
				if(name == 49){ //value ng 1 sa ascii
				mode=1;
				goto choosemenu;
					break;
				}
				if(name == 50){ //value ng 2 sa ascii
				mode=2;
				goto choosemenu;
					break;
				}
			choosemenu:
			switch(mode){
				case 1:{
					system ("CLS");
					aCircle();
					break;
				}
				case 2:{
					system ("CLS");
					menu();
					break;
				}
			}
		}
	}	
}


void menu ()
{
	int x,y;
	int xx,yy;
	//horizontals
	system ("color B0");
	for(x=7;x<=110;x++)
	{
		g(x,27);cout<<"�";
		g(x,3);cout<<"�";
	}
	//verticals
	
	for(y=3;y<=27;y++)
	{
		g(7,y);cout<<"�";
		g(82,y);cout<<"�";	
		g(35,y);cout<<"�";	
		g(110,y);cout<<"�";
	}
	for (y=0;y<=1;y++)
	for (x=0;x<=119;x++)
	{
		g(x,y);cout<<"�";
	}
	for (x=0;x<=119;x++)
	{
		g(x,29);cout<<"�";
	}
	for (y=0;y<=29;y++)
	for (x=0;x<=5;x++)
	{
		g(x,y);cout<<"�";
	}
	for (y=0;y<=29;y++)
	for (x=112;x<=119;x++)
	{
		g(x,y);cout<<"�";
	}
	
	
}

void numbawan()
{
	
}

void exshits()
{	
	g(48,10);cout<<"DO YOU WANT TO EXIT?";
	g(51,13);cout<<"< N > HELL NO!";
	g(50,15);cout<<"< Y > HELL YEAH!";
}


int main()
{

	again:
	system ("CLS");
	int control;
	menu();
	
	g(53,8);cout<<"EXERCISE #1";
	g(49,10);cout<<"DIZON, GEM JASON N.";
	g(52,12);cout<<"BS CPE 2 - 1";
	g(48,15);cout<<"< 1 > Areas of Polygon";
	g(47,17);cout<<"< 2 > Greatest Number";
	g(46,19);cout<<"< 3 > Factorial";
	g(52,23);cout<<"< esc > EXIT";
	
	while(1)
	{
			if(kbhit())
			{
				control=getch();
				if(control == 49)//1
				{ 
					system ("CLS");
					numbawan();
					break;
				}
			
			}
			else if(kbhit())
			{
				control=getch();
				if(control == 50)//2
				{ 		
					system ("CLS");
					nambatu();
					break;				
				}
			}
			else if(kbhit())
			{
				control=getch();
				if(control == 51)//3
				{ 
					system ("CLS");
					nambatri();
					break;		
				}
			}
		
			else if(kbhit())
			{
				control=getch();
				if(control == 27)//esc
				{ 	
					system ("CLS");
					menu();
					exshits();
					
		while(1)
		{
			if(kbhit())
			{
				control=getch();
				if(control == 'y')//y
				{ 
					system ("CLS");
					exit(1);
					break;
				}
				else if(control == 'n')//y
				{ 
					system ("CLS");
					goto again;
					break;
				}
       	 	}
		}
					break;
				}
			}
	}
	
}
