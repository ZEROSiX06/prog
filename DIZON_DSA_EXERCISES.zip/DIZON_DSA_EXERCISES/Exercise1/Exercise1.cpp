#include<iostream>
#include<windows.h>
#include <bits/stdc++.h>
#include<conio.h>
#include<stdio.h>
#include <string.h>
#include<ctime>
#include<cstdlib>
#include<time.h>
#define g gotoxy


using namespace std;

void menu();
int main();
void exshits();
void nambawan();
void nambatu();
void nambatri();
void nambapor();
int control;
void gotoxy( int column, int line )
{
	HANDLE screen = GetStdHandle( STD_OUTPUT_HANDLE );
	COORD max_size = GetLargestConsoleWindowSize( screen );
	COORD coord;
	coord.X = column;
	coord.Y = line;
	SetConsoleCursorPosition(GetStdHandle( STD_OUTPUT_HANDLE ),coord);
}

//Ascending shits
void nambawan()
{
    int i, j, temp, arr[10];
    again:
	system ("CLS"); 
	
	arr[10] = 0;
	temp = 0;
	i = 0;
	j = 0;
	
    menu();
    g(37,7);cout << "Enter ten numbers: \n";
	g(60,7);cout << "Ascending order:\n";
    for (i=0; i<10; i++)
    {
      g(40,i+9);  cin.ignore(); cin>>arr[i];
    }
    
    if(cin.fail())
	{
    cin.clear();	
    g(37,24);cout<<"Wrong Input";
    g(37,25);cout<<"Press any key to try again";
    getch();
    goto again;
	}
	
    for (i=0;i<10;i++)
    {
        for (j=i+1; j<10; j++)
        {
            if (arr[i]>arr[j])
            {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
    
    for (i=0; i<10; i++)
    {
    	g(60,i+9);cout << arr[i] <<" ";
    }

    g(37,24);cout<<"Press 1 to Input again";
    g(37,25);cout<<"Press esc to go back to menu";
    
      	while(1)
	{
			if(kbhit())
			{
				control=getch();
				if(control == 49)//1
				{ 
					system ("CLS");
					goto again;
					break;
				}
       	 	}
       	 	else if(kbhit())
			{
				control=getch();
				if(control == 27)//esc
				{ 
					system ("CLS");
					menu();
					exshits();
					
		while(1)
		{
			if(kbhit())
			{
				control=getch();
				if(control == 'y')//y
				{ 
					system ("CLS");
					main();
					break;
				}
				else if(control == 'n')//y
				{ 
					system ("CLS");
					goto again;
					break;
				}
       	 	}
		}	
		
					break;
				}
       	 	}
	}
       
	
}

void nambatu()
{
	again:
	system ("CLS"); 
    menu();
    
	int a[10], n=0, i=0;  
	
	g(37,7);cout<<"Enter an Integer: ";
	g(37,12);cout<<"Binary equivalent: ";       
	g(37,8);cin.ignore();cin>>n;    
	
	 if(cin.fail())
	{
    cin.clear();	
    g(37,24);cout<<"Wrong Input";
    g(37,25);cout<<"Press any key to try again";
    getch();
    goto again;
	}
	
	for(i=0; n>0; i++)    
	{    
		a[i]=n%2;    
		n= n/2;  
	}  
	  
	g(37,13);
	for(i=i-1 ;i>=0 ;i--)    
	{	    
		cout<<a[i];    
	} 
	
	g(37,24);cout<<"Press 1 to Input again";
    g(37,25);cout<<"Press esc to go back to menu";
    
      	while(1)
	{
			if(kbhit())
			{
				control=getch();
				if(control == 49)//1
				{ 
					system ("CLS");
					goto again;
					break;
				}
       	 	}
       	 	else if(kbhit())
			{
				control=getch();
				if(control == 27)//esc
				{ 
					system ("CLS");
					menu();
					exshits();
					
		while(1)
		{
			if(kbhit())
			{
				control=getch();
				if(control == 'y')//y
				{ 
					system ("CLS");
					main();
					break;
				}
				else if(control == 'n')//y
				{ 
					system ("CLS");
					goto again;
					break;
				}
       	 	}
		}
					break;
				}
       	 	}
	}
	   
}

void nambatri()
{	again:
    int  i, j; 
	double arr[10] = {0},x, max, min;
	
	char z = arr[i];
	double er = 0.00;
	char space = 32;
	
	


	cin.clear();
	system ("CLS"); 
	menu();
	g(37,7);
    cout << "Enter ten numbers: ";
    g(60,7);cout << "1st to the highest: " ;
    g(60,10);cout << "2nd to the highest: " ;
    g(60,13);cout << "1st to the smallest: " ;
    g(60,16);cout << "2nd to the smallest: " ;
   
    for (i=0; i<10; i++)
	{
       g(40,i+9);  cin.ignore(); cin>> arr[i];
		max = arr[0];
		
	if(cin.fail())
	{
    cin.clear();	
    g(37,24);cout<<"Wrong Input";
    g(37,25);cout<<"Press any key to try again";
    getch();
    goto again;
	}
	
		
	if(arr[i] == -0 )
	{
    cin.clear();	
    g(37,24);cout<<"Zero's are not allowed'";
    g(37,25);cout<<"Press any key to try again";
    getch();
    goto again;
	}
	if(z == 32)
	{
    cin.clear();	
    g(37,24);cout<<"Wrong Input";
    g(37,25);cout<<"Press any key to try again";
    getch();
    goto again;
	}
	
	
	
	
	
	
	}
    for (i=0; i <10; i++)
    {
        if (max < arr[i])
            max = arr[i];
    }
    	min = arr[0];
    for (i=0; i<10; i++)
    {
        if (min > arr[i])
            min = arr[i];
    }
	    
    for (i = 0; i<10; i++)
    {
        for (j=i+1; j<10; j++)
        {
            if (arr[i] < arr[j])
            {
                x = arr[i];
                arr[i] = arr[j];
                arr[j] = x;
            }
        }
    }
    
	g(67,8);cout<< max;
	g(67,11);cout<< arr[1];
	g(67,14);cout<< min;
	g(67,17);cout<< arr[10 - 2];
    
    g(37,24);cout<<"Press 1 to Input again";
    g(37,25);cout<<"Press esc to go back to menu";
    
      	while(1)
	{
			if(kbhit())
			{
				control=getch();
				if(control == 49)//1
				{ 
					system ("CLS");
					goto again;
					break;
				}
       	 	}
       	 	else if(kbhit())
			{
				control=getch();
				if(control == 27)//esc
				{ 
					system ("CLS");
					menu();
					exshits();
					
		while(1)
		{
			if(kbhit())
			{
				control=getch();
				if(control == 'y')//y
				{ 
					system ("CLS");
					main();
					break;
				}
				else if(control == 'n')//y
				{ 
					system ("CLS");
					goto again;
					break;
				}
       	 	}
		}
					break;
				}
       	 	}
	}
    
}

void nambapor()
{
	again:
    system ("CLS"); 
	char p[20] = {0};
	int x = 0, length = 0;
	int check = 0;
	
    menu();
	g(37,7);cout << "Enter a word: ";
	g(37,9); cin>> p;
	length = strlen(p);
	
	for(x;x<length ; x++)
	{
		if (p[x] != p[length -x - 1])
		{
			check =1;
			break;
		}
	}
	
	if(check)
	{
		g(37,12);	cout << p << " is not a palindrome";
	}
	else 
	{
		g(37,12);	cout << p << " is a palindrome";
	}
	
	
	     
    g(37,24);cout<<"Press 1 to Input again";
    g(37,25);cout<<"Press esc to go back to menu";
    
      	while(1)
	{
			if(kbhit())
			{
				control=getch();
				if(control == 49)//1
				{ 
					system ("CLS");
					goto again;
					break;
				}
       	 	}
       	 	else if(kbhit())
			{
				control=getch();
				if(control == 27)//esc
				{ 
					system ("CLS");
					menu();
					exshits();
					
		while(1)
		{
			if(kbhit())
			{
				control=getch();
				if(control == 'y')//y
				{ 
					system ("CLS");
					main();
					break;
				}
				else if(control == 'n')//N0
				{ 
					system ("CLS");
					goto again;
					break;
				}
       	 	}
		}
					break;
				}
       	 	}
	}
}

void menu ()
{
	int x,y;
	int xx,yy;
	//horizontals
	system ("color B0");
	for(x=7;x<=110;x++)
	{
		g(x,27);cout<<"�";
		g(x,3);cout<<"�";
	}
	//verticals
	
	for(y=3;y<=27;y++)
	{
		g(7,y);cout<<"�";
		g(82,y);cout<<"�";	
		g(35,y);cout<<"�";	
		g(110,y);cout<<"�";
	}
	for (y=0;y<=1;y++)
	for (x=0;x<=119;x++)
	{
		g(x,y);cout<<"�";
	}
	for (x=0;x<=119;x++)
	{
		g(x,29);cout<<"�";
	}
	for (y=0;y<=29;y++)
	for (x=0;x<=5;x++)
	{
		g(x,y);cout<<"�";
	}
	for (y=0;y<=29;y++)
	for (x=112;x<=119;x++)
	{
		g(x,y);cout<<"�";
	}
	
	
}

void exshits()
{	
	g(48,10);cout<<"DO YOU WANT TO EXIT?";
	g(51,13);cout<<"< N > HELL NO!";
	g(50,15);cout<<"< Y > HELL YEAH!";
}



int main()
{
	again:
	system ("CLS");
	int control;
	menu();
	
	g(53,8);cout<<"EXERCISE #1";
	g(56,10);cout<<"Dizon";
	g(52,12);cout<<"BS CPE 2 - 1";
	g(48,15);cout<<"< 1 > Ascending Order";
	g(47,17);cout<<"< 2 > Decimal to Binary";
	g(46,19);cout<<"< 3 > Highest and Lowest";
	g(50,21);cout<<"< 4 > Palindrome";
	g(52,23);cout<<"< esc > EXIT";
	
	while(1)
	{
			if(kbhit())
			{
				control=getch();
				if(control == 49)//1
				{ 
					system ("CLS");
					nambawan();
					break;
				}
			
			}
			else if(kbhit())
			{
				control=getch();
				if(control == 50)//2
				{ 		
					system ("CLS");
					nambatu();
					break;				
				}
			}
			else if(kbhit())
			{
				control=getch();
				if(control == 51)//3
				{ 
					system ("CLS");
					nambatri();
					break;		
				}
			}
			else if(kbhit())
			{
				control=getch();
				if(control == 52)//4
				{ 
				
					system ("CLS");
					nambapor();
					break;
					
				}
			}
			else if(kbhit())
			{
				control=getch();
				if(control == 27)//esc
				{ 	
					system ("CLS");
					menu();
					exshits();
					
		while(1)
		{
			if(kbhit())
			{
				control=getch();
				if(control == 'y')//y
				{ 
					system ("CLS");
					exit(1);
					break;
				}
				else if(control == 'n')//y
				{ 
					system ("CLS");
					goto again;
					break;
				}
       	 	}
		}
					break;
				}
			}
	}
	
	
	
}

