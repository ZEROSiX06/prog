#include <stdio.h>
#include <string.h>
#define MAX_SIZE 100
 
 
void stringCat (char *s1,char *s2);
 
 
int main()
{
    char str1[MAX_SIZE],str2[MAX_SIZE];
    
    printf("************************\n"
			"STRING CONCATENATION\n"
			"************************\n");

    printf("Enter a first word (str1): ");
    scanf("%[^\n]s",str1);
 
	getchar();
 
    printf("Enter a second word (str2): ");
    scanf("%[^\n]s",str2);
 
    stringCat(str1,str2);
    printf("new string value for str1: %s",str1,str2);
 
    printf("\n");
    return 0;
}
 
void stringCat (char *s1,char *s2)
{
    int len,i;
    len=strlen(s1)+strlen(s2);
    if(len>MAX_SIZE)
    {
        printf("\nCan not Concatenate !!!");
        return;
    }
     
    len=strlen(s1);
    for(i=0;i< strlen(s2); i++)
    {
        s1[len+i]=s2[i];
    }
    s1[len+i]='\0';
}
