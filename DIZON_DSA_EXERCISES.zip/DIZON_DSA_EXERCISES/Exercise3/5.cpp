#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

int main(){
	string str;

	cout << "Enter some string: ";
	getline(cin, str);

	for_each(str.begin(), str.end(), [](char & c)){
		static int last = ' ';
		if(last == ' ' && c != ' ' && ::isalpha(c))
		c = ::toupper(c);
		last = c;
	}
	
	cout << str << endl;
	system("pause>0");
	return 0;
}
