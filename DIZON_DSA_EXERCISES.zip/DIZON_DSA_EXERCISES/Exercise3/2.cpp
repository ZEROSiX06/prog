#include <iostream>
#include <cstring>

using namespace std;

int main(){
	char str1[100], str2[100];

	cout << "Enter the first word (str1): ";
	cin.getline(str1, 100);
	cout << "Enter the second word (str2): ";
	cin.getline(str2, 100);

	strcpy(str1, str2);
	cout << "New string value for str1: " << str1 << endl;

	system("pause>0");
	return 0;
}
